close all;
clear;
items = {'Bread', 'Milk', 'Coronas', 'Diapers', 'shoes', 'clothes', 'cookies', 'chips', 'toys', 'movies'};

%creates random matrix of zeros and 1's
randomBinary = randi([0,1],1000,10); 

%the final matrix we use
output = cell(1001,11);

%loop in order to get the list of items present in randomBinary
for i = 1: 1000
    count = 0;
    for j = 1: 10
         if randomBinary(i,j)==1
             count = count + 1;
      newList(j,i) =  items(j);
         end
    end
end

%loop from the new list in order to concatinate them
for y = 1: 1000
    itemList = ' ';
    for x = 1: 10
           itemList = strcat(itemList, {' '},newList{x,y});

    end
    %puts it into a row that we will export
    output(y,1) = itemList;
end

%csvwrite('zero_one.csv',randomBinary);
%writecell(output,'items.csv');
% I transpose them manually in excell you can uncomment the las two lines
% if you wanna export them